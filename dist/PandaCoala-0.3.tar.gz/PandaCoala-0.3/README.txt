
Start exec.sh for usage,
you can also pass arguments.


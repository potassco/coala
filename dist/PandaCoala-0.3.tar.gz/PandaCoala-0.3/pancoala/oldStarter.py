import sys

import b.translator
import bc.translator
from pancoala import stateBuilder


class Starter(object):

    def __init__(self,argv):
        self.language = "BC"
        self.doWrite = True
        self.debug = False
        
    def start(self):
        
        print "Start testcases"
        
        files = [ "testcases/test1.bc",
            "testcases/test2.bc",
            "testcases/test3.bc",
            "testcases/test4.bc",
            "testcases/test5.bc",
            "testcases/test6.bc",
            "testcases/test7.bc",
            "testcases/test8.bc",
            "testcases/test9.bc",
            "testcases/test_false.bc",
            "testcases/test_true.bc",
            "testcases/test_where.bc",
            "testcases/test_evil.bc",
            "testcases/test_nex.bc"]
        outfiles = [ "temp/fact_test1.bc.lp",
            "temp/fact_test2.bc.lp",
            "temp/fact_test3.bc.lp",
            "temp/fact_test4.bc.lp",
            "temp/fact_test5.bc.lp",
            "temp/fact_test6.bc.lp",
            "temp/fact_test7.bc.lp",
            "temp/fact_test8.bc.lp",
            "temp/fact_test9.bc.lp",
            "temp/fact_test_false.bc.lp",
            "temp/fact_test_true.bc.lp",
            "temp/fact_test_where.bc.lp",
            "temp/fact_test_evil.bc.lp",
            "temp/fact_test_nex.bc.lp"]
        self.test_cases_bc(files,outfiles)
        #self.test_cases_bc(["testcases/test_nex.bc"], ["temp/fact_test_nex.bc.lp"])
        
        #self.test_b()
        
        print "End testcases"
        
    def test_b(self):
        #self.debug = True
        bt = b.translator.Translator()
        #bt.translate_file("testcases/test1.b", "testcases/test1.b.lp",writeFile=False,ignoreErrors=True)
        #bt.translate_file("testcases/test_where.b", "temp/test_where.b.lp",debug=self.debug,writeFile=self.doWrite,ignoreErrors=True)
        #bt.translate_file("testcases/bug.b", "temp/bug.b.lp",debug=self.debug,writeFile=self.doWrite,ignoreErrors=True)
        bt.translate_file("testcases/bug2.b", "temp/bug2.b.lp",debug=self.debug,write_file=self.doWrite,ignore_errors=True)
        
    def test_cases_bc(self,files,outfiles):
        if len(files) != len(outfiles):
            if self.doWrite:
                print "Error: Not enough output filenames"
                return
            print "Warning: Not enough output filenames"
        tr = bc.translator.Translator()
        for i in range(len(files)):
            fi = files[i]
            if i in range(len(outfiles)): ou = outfiles[i]
            else: ou = fi+".lp"
            print "__________________\r\n",fi," : \r\n"
            output = tr.translate_file(fi, ou,debug=self.debug,write_file=self.doWrite,ignore_errors=True)
            #output = tr.translate_file(fi, "../temp/temp.lp")
            if output != None: print output
        print "__________________\r\n"
        
    def test_1(self):
        #tr = bc.translator.Translator(compiler='aspReducedCompiler')
        #output = tr.translate_file("../temp/test2.bc", "../temp/test2_facts.lp",False)
        
        tr = bc.translator.Translator()
        output = tr.translate_file("../temp/test.bc", "../temp/test_facts.lp")
        
        if output != None: print "Translation written to ",output
        
if __name__ == '__main__':
    
    if len(sys.argv) > 1:
        inputfile = sys.argv[1]
        if len(sys.argv) > 2:
            outputfile = sys.argv[2]
            tr = bc.translator.Translator()
            output = tr.translate_file(inputfile, outputfile, ignore_errors=True)
        else:
            tr = bc.translator.Translator(silent=True)
            output = tr.translate_file(inputfile, inputfile+".lp",write_file=False,ignore_errors=True)
    else:
        start = Starter(sys.argv)
        start.start()
        
        #statebu = stateBuilder.StateBuilder()
        #statebu.start("testcases/statebuild.bc")
    
    
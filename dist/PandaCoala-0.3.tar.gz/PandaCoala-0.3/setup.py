from distutils.core import setup

setup(
    # Application name:
    name="PandaCoala",

    # Version number (initial):
    version="0.3",

    # Application author details:
    author="Christian Schulz-Hanke",
    author_email="Christian.Schulz-Hanke@cs.uni-potsdam.de",

    # Packages
    packages=["pancoala","pancoala.bc","pancoala.b","pancoala.bcAgent","ply"],

    #
    scripts=["pancoala/pancoala"],

    # Include additional files into the package
    #include_package_data=True,

    # Details
    #url="about:blank",

    #
    # license="LICENSE.txt",
    description="PandaCoala - Action Language Translation Tool.",

    # long_description=open("README.txt").read(),

    # Dependent packages (distributions)
    #install_requires=[
    #    "flask",
    #],
)

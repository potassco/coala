from distutils.core import setup
from distutils.command.install import INSTALL_SCHEMES

for scheme in INSTALL_SCHEMES.values():
    scheme['data'] = scheme['purelib']

setup(
    # Application name:
    name="bc2asp",

    # Version number (initial):
    version="0.4",

    # Application author details:
    author="Christian Schulz-Hanke",
    author_email="Christian.Schulz-Hanke@cs.uni-potsdam.de",

    # Packages
    packages=["bc2asp","bc2asp.parse","bc2asp.bc","bc2asp.bc_legacy","bc2asp.bcLc","bc2asp.b","bc2asp.bcAgent","bc2asp.bcAgent_legacy","ply"],

    #
    scripts=["bc2asp/bc2asp","outputformatclingobc2asp"],

    # Include additional files into the package
    #include_package_data=True,

    # Details
    url="http://www.cs.uni-potsdam.de/wv/bc2asp/",

    #
    # license="LICENSE.txt",
    description="bc2asp - Action Language Translation Tool.",

    # long_description=open("README.txt").read(),
    long_description=open("README.txt").read(),

    # Dependent packages (distributions)
    #install_requires=[
    #    "flask",
    #],

    data_files=[('', ['README_BC.txt'])]+ \
             [
            ("encodings",["encodings/base.lp", "encodings/base_translation.lp", \
                "encodings/csp.lp", "encodings/incremental.lp", "encodings/incremental_clingo.lp", "encodings/solve_incremental.lp"]), \
            ("encodings/internal", ["encodings/internal/arithmetic.lp", \
                "encodings/internal/csp.lp", \
                "encodings/internal/fixed.lp", \
                "encodings/internal/fixed_not_decoupled.lp", \
                "encodings/internal/iterative.lp", \
                "encodings/internal/iterative_not_decoupled.lp", \
                "encodings/internal/states.lp", \
                "encodings/internal/states_not_decoupled.lp", \
                "encodings/internal/transitions.lp", \
                "encodings/internal/transitions_not_decoupled.lp"])
            ]
)

# Build: python setup.py sdist
